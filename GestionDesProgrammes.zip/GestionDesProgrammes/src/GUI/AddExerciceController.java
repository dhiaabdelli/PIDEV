/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import services.ExerciceCRUD;
import entities.Exercice;
import entities.ExerciceAssocie;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import services.ExerciceAssocieCRUD;
import services.ExerciceCRUD;

/**
 * FXML Controller class
 *
 * @author dell
 */
public class AddExerciceController implements Initializable {

    @FXML
    private TextField tfimage;
    @FXML
    private TextField tflibelle;
    @FXML
    private TextField tfdescription;
    @FXML
    private Button btnajouterEx;
    @FXML
    private Button btnmodifierEx;
    @FXML
    private Button btnsupprimerEx;
    @FXML
    private Button btnafficherEx;
    @FXML
    private TextField tfnbrepetition;
    @FXML
    private Button btnajouterExA;
    @FXML
    private Button btnmodifierExA;
    @FXML
    private Button btnsupprimerExA;
    @FXML
    private Button btnafficherExA;
    @FXML
    private TextField tfjour;

    @FXML
    private TableView<Exercice> tableEx;

    @FXML
    private TableColumn<Exercice, Integer> colid;

    @FXML
    private TableColumn<Exercice, String> colimage;

    @FXML
    private TableColumn<Exercice, String> collibelle;

    @FXML
    private TableColumn<Exercice, String> coldescription;

    ObservableList<Exercice> listM;
    ObservableList<ExerciceAssocie> listMA;
    @FXML
    private TableColumn<ExerciceAssocie, Integer> colidprofile;
    @FXML
    private TableColumn<ExerciceAssocie, Integer> colidexercice;
     @FXML
    private TableColumn<ExerciceAssocie, Integer> colNbSeries;
    @FXML
    private TableColumn<ExerciceAssocie, Integer> colnbrepetition;
    @FXML
    private TableColumn<ExerciceAssocie, Integer> coljour;
    @FXML
    private TableView<ExerciceAssocie> tableExA;
    @FXML
    private TextField tfidProfile;
    @FXML
    private TextField tfNbSeries;
   

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        updatetableEx();
        initEx();
        updatetableExA();
        initExA();
    }
    
    public void updatetableEx(){
        listM = ExerciceCRUD.AfficheEx();
        colid.setCellValueFactory(new PropertyValueFactory<>("Id"));
        colimage.setCellValueFactory(new PropertyValueFactory<>("Image"));
        collibelle.setCellValueFactory(new PropertyValueFactory<>("Libelle"));
        coldescription.setCellValueFactory(new PropertyValueFactory<>("Description"));
        tableEx.setItems(listM); 
    }
    
    public void initEx(){
        tfimage.clear();
        tflibelle.clear();
        tfdescription.clear();
    }
    
    @FXML
    private void ajouterExercice(ActionEvent event) {
        //SAVE EXERCICE IN DATABASE
        String rimage = tfimage.getText();
        String rlibelle = tflibelle.getText();
        String rdescrption = tfdescription.getText();
        Exercice e = new Exercice(13, rlibelle, rdescrption, rimage);
        ExerciceCRUD ecd = new ExerciceCRUD();
        ecd.addExercice(e);
       
        updatetableEx();
        initEx();
    }
    
    @FXML
    private void hez_lghadi_EX(MouseEvent event) {
        tfimage.setText(tableEx.getSelectionModel().getSelectedItem().getImage());
        tflibelle.setText(tableEx.getSelectionModel().getSelectedItem().getLibelle());
        tfdescription.setText(tableEx.getSelectionModel().getSelectedItem().getDescription());
    }

    @FXML
    private void modifierExercice(ActionEvent event) {
        String rimage = tfimage.getText();
        String rlibelle = tflibelle.getText();
        String rdescrption = tfdescription.getText();
        Exercice e = new Exercice(tableEx.getSelectionModel().getSelectedItem().getId(), rlibelle, rdescrption, rimage);
        ExerciceCRUD ecd = new ExerciceCRUD();
        ecd.modifierExercice(e);
        
        updatetableEx();
        initEx();
    }

    @FXML
    private void SupprimerExercice(ActionEvent event) {
        ExerciceCRUD ecd = new ExerciceCRUD();
        ecd.supprimerExercice(tableEx.getSelectionModel().getSelectedItem().getId());
        
        updatetableEx();
        initEx();        
    }

    @FXML
    private void afficherExercice(ActionEvent event) {

        listM = ExerciceCRUD.AfficheEx();
        colid.setCellValueFactory(new PropertyValueFactory<>("Id"));
        colimage.setCellValueFactory(new PropertyValueFactory<>("Image"));
        collibelle.setCellValueFactory(new PropertyValueFactory<>("Libelle"));
        coldescription.setCellValueFactory(new PropertyValueFactory<>("Description"));
        tableEx.setItems(listM);
    }

      @FXML
    private void hez_lghadi_EXA(MouseEvent event) {
        tfidProfile.setText(String.valueOf(tableExA.getSelectionModel().getSelectedItem().getIdProfile()));
        tfNbSeries.setText(String.valueOf(tableExA.getSelectionModel().getSelectedItem().getNbSeries()));
        tfnbrepetition.setText(String.valueOf(tableExA.getSelectionModel().getSelectedItem().getNbRepetitions()));
        tfjour.setText(String.valueOf(tableExA.getSelectionModel().getSelectedItem().getJour()));
    } 
    
    public void updatetableExA(){
        listMA = ExerciceAssocieCRUD.AfficheExA();
        colidprofile.setCellValueFactory(new PropertyValueFactory<>("idProfile"));
        colidexercice.setCellValueFactory(new PropertyValueFactory<>("idExercice"));
        colNbSeries.setCellValueFactory(new PropertyValueFactory<>("nbSeries"));
        colnbrepetition.setCellValueFactory(new PropertyValueFactory<>("nbRepetitions"));
        coljour.setCellValueFactory(new PropertyValueFactory<>("Jour"));
        tableExA.setItems(listMA);
    }
    
    public void initExA(){
        tfidProfile.clear();
        tfidProfile.clear();
        tfNbSeries.clear();
        tfnbrepetition.clear();
        tfjour.clear();
    }
    @FXML
    private void ajouterExerciceAssocier(ActionEvent event) {
         //SAVE EXERCICE IN DATABASE
         
        String ridprofile = tfidProfile.getText();
        String rnbseries = tfNbSeries.getText();
        String rnbrepetition = tfnbrepetition.getText();
        String rjour = tfjour.getText();
        ExerciceAssocie ea = new ExerciceAssocie(Integer.parseInt(ridprofile), 22,Integer.parseInt(rnbseries) , Integer.parseInt(rnbrepetition), Integer.parseInt(rjour));
        ExerciceAssocieCRUD eacd = new ExerciceAssocieCRUD();
        eacd.addExerciceAssocie(ea);
    }

    @FXML
    private void modifierExerciceAssocier(ActionEvent event) {
        String ridprofile = tfidProfile.getText();
        String rnbseries = tfNbSeries.getText();
        String rnbrepetition = tfnbrepetition.getText();
        String rjour = tfjour.getText();
        ExerciceAssocie ea = new ExerciceAssocie(Integer.parseInt(ridprofile), tableExA.getSelectionModel().getSelectedItem().getIdExercice(),Integer.parseInt(rnbseries) , Integer.parseInt(rnbrepetition), Integer.parseInt(rjour));
        ExerciceAssocieCRUD eacd = new ExerciceAssocieCRUD();
        eacd.modifierExerciceAssocie(ea);    
        
        updatetableExA();
        initExA();        
        
    }

    @FXML
    private void supprimerExerciceAssocier(ActionEvent event) {
         ExerciceAssocieCRUD eacd = new ExerciceAssocieCRUD();
        eacd.supprimerExerciceAssocie(tableExA.getSelectionModel().getSelectedItem().getIdExercice());
                
        updatetableExA();
        initExA();    
    }


    @FXML
    private void afficherExerciceAss(ActionEvent event) {
        listMA = ExerciceAssocieCRUD.AfficheExA();
        colidprofile.setCellValueFactory(new PropertyValueFactory<>("idProfile"));
        colidexercice.setCellValueFactory(new PropertyValueFactory<>("idExercice"));
        colNbSeries.setCellValueFactory(new PropertyValueFactory<>("nbSeries"));
        colnbrepetition.setCellValueFactory(new PropertyValueFactory<>("nbRepetitions"));
        coljour.setCellValueFactory(new PropertyValueFactory<>("Jour"));
        tableExA.setItems(listMA);
    }




}
