package Presentation;

import Entities.aliment;
import Services.AlimentService;
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIcon;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;

public class backofficeAlimentController implements Initializable {

    @FXML
    private TableView<aliment> tabAliments;
    @FXML
    private TableColumn<aliment, String> nomAlim;
    @FXML
    private TableColumn<aliment, Integer> fatAlim;
    @FXML
    private TableColumn<aliment, Integer> carbAlim;
    @FXML
    private TableColumn<aliment, Integer> protAlim;
    @FXML
    private TableColumn<aliment, Integer> calAlim;
    @FXML
    private TextField nomAdd;
    @FXML
    private TextField fatsAdd;
    @FXML
    private TextField carbsAdd;
    @FXML
    private TextField protAdd;
    @FXML
    private TextField calAdd;
    @FXML
    private TextField nomEdit;
    @FXML
    private TextField fatsEdit;
    @FXML
    private TextField carbsEdit;
    @FXML
    private TextField protEdit;
    @FXML
    private TextField calEdit;
    private static aliment selected = null;
    @FXML
    private FontAwesomeIcon editButton;
    @FXML
    private FontAwesomeIcon addButton; 

    @Override
    public void initialize(URL url, ResourceBundle rb){
        refresh();
    }    

    private void refresh(){
        AlimentService as = new AlimentService();
        ObservableList <aliment> data = FXCollections.observableArrayList(as.listerAliments());
        nomAlim.setCellValueFactory(new PropertyValueFactory<>("nom"));
        fatAlim.setCellValueFactory(new PropertyValueFactory<>("fats"));
        carbAlim.setCellValueFactory(new PropertyValueFactory<>("carbs"));
        protAlim.setCellValueFactory(new PropertyValueFactory<>("proteins"));
        calAlim.setCellValueFactory(new PropertyValueFactory<>("calories"));
        tabAliments.setItems(data);
        tabAliments.setOnMouseClicked(this::onitemselect);
    }
    
    void onitemselect(MouseEvent event) {
        if(tabAliments.getSelectionModel().getSelectedItem() != null){
            selected = tabAliments.getSelectionModel().getSelectedItem();
            nomEdit.setText(tabAliments.getSelectionModel().getSelectedItem().getNom());
            fatsEdit.setText(Integer.toString(tabAliments.getSelectionModel().getSelectedItem().getFats()));
            carbsEdit.setText(Integer.toString(tabAliments.getSelectionModel().getSelectedItem().getCarbs()));
            protEdit.setText(Integer.toString(tabAliments.getSelectionModel().getSelectedItem().getProteins()));
            calEdit.setText(Integer.toString(tabAliments.getSelectionModel().getSelectedItem().getCalories()));
            nomEdit.setDisable(false);
            fatsEdit.setDisable(false);
            carbsEdit.setDisable(false);
            protEdit.setDisable(false);
            calEdit.setDisable(false);
            editButton.setDisable(false);
            nomAdd.setDisable(true);
            fatsAdd.setDisable(true);
            carbsAdd.setDisable(true);
            protAdd.setDisable(true);
            calAdd.setDisable(true);
            addButton.setDisable(true);
        }
    }
    
    @FXML
    private void addAliment(MouseEvent event){
        AlimentService as = new AlimentService();
        int type = 0;
        if(Integer.parseInt(protAdd.getText()) > Integer.parseInt(carbsAdd.getText()) && Integer.parseInt(protAdd.getText()) > Integer.parseInt(fatsAdd.getText())){
            type = 0;
        }
        if(Integer.parseInt(carbsAdd.getText()) > Integer.parseInt(protAdd.getText()) && Integer.parseInt(carbsAdd.getText()) > Integer.parseInt(fatsAdd.getText())){
            type = 1;
        }
        if(Integer.parseInt(fatsAdd.getText()) > Integer.parseInt(carbsAdd.getText()) && Integer.parseInt(fatsAdd.getText()) > Integer.parseInt(protAdd.getText())){
            type = 2;
        }
        aliment a = new aliment(as.getMaxId(),(String) nomAdd.getText(), Integer.parseInt(fatsAdd.getText()), Integer.parseInt(carbsAdd.getText()), Integer.parseInt(protAdd.getText()), Integer.parseInt(calAdd.getText()), type);
        as.ajouterAliment(a);
        refresh();
    }

    @FXML
    private void editAliment(MouseEvent event){
        AlimentService as = new AlimentService();
        int type = 0;
        if(Integer.parseInt(protEdit.getText()) > Integer.parseInt(carbsEdit.getText()) && Integer.parseInt(protEdit.getText()) > Integer.parseInt(fatsEdit.getText())){
            type = 0;
        }
        if(Integer.parseInt(carbsEdit.getText()) > Integer.parseInt(protEdit.getText()) && Integer.parseInt(carbsEdit.getText()) > Integer.parseInt(fatsEdit.getText())){
            type = 1;
        }
        if(Integer.parseInt(fatsEdit.getText()) > Integer.parseInt(carbsEdit.getText()) && Integer.parseInt(fatsEdit.getText()) > Integer.parseInt(protEdit.getText())){
            type = 2;
        }
        aliment a = new aliment(tabAliments.getSelectionModel().getSelectedItem().getId(),(String) nomEdit.getText(), Integer.parseInt(fatsEdit.getText()), Integer.parseInt(carbsEdit.getText()), Integer.parseInt(protEdit.getText()), Integer.parseInt(calEdit.getText()), type);
        as.modifierAliment(a);
        nomEdit.setDisable(true);
        fatsEdit.setDisable(true);
        carbsEdit.setDisable(true);
        protEdit.setDisable(true);
        calEdit.setDisable(true);
        editButton.setDisable(true);
        nomAdd.setDisable(false);
        fatsAdd.setDisable(false);
        carbsAdd.setDisable(false);
        protAdd.setDisable(false);
        calAdd.setDisable(false);
        addButton.setDisable(false);
        refresh();
    }

    @FXML
    private void deleteAliment(MouseEvent event){
        if(selected != null){
            AlimentService as = new AlimentService();
            as.supprimerAliment(tabAliments.getSelectionModel().getSelectedItem().getId());
            nomEdit.setDisable(true);
            fatsEdit.setDisable(true);
            carbsEdit.setDisable(true);
            protEdit.setDisable(true);
            calEdit.setDisable(true);
            editButton.setDisable(true);
            nomAdd.setDisable(false);
            fatsAdd.setDisable(false);
            carbsAdd.setDisable(false);
            protAdd.setDisable(false);
            calAdd.setDisable(false);
            addButton.setDisable(false);
            refresh();
        }
    }
    
}
